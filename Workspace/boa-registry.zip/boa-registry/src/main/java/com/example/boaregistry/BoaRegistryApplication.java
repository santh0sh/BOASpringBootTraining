package com.example.boaregistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoaRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaRegistryApplication.class, args);
	}

}
