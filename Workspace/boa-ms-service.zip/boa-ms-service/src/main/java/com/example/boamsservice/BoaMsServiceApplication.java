package com.example.boamsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoaMsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaMsServiceApplication.class, args);
	}

}
