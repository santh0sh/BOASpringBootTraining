package com.example.springmvcrabitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcRabitmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
