package com.example.springmvcrabitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcRabitmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcRabitmqApplication.class, args);
	}

}
