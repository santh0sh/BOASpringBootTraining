package com.example.boaspringdes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaSpringDesApplicationTests {

	@Test
	void contextLoads() {
	}

}
