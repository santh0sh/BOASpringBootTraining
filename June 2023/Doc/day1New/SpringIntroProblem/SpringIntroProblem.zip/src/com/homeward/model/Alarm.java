package com.homeward.model;

public interface Alarm {
	void activate();
	void deactivate();

}
